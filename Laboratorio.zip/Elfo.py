from Personaje import Personaje

class Elfo(Personaje):
    def __init__(self, nombre,raza,arma,vida,dano,bonif,reino):
        super().__init__(nombre,raza,arma,vida,dano,bonif)
        self.__reino = reino

    def get_reino(self):
        return self.__reino   

    def set_reino(self, reino):
        self.__reino = reino

    def historia(self):
        print("Este elfo proviene de un lejano reino.")

    def victoria(self):
        print("Victoria de elfo!!")
    
    def derrota(self):
        print("Un elfo ha sido derrotado")

    def quita_vida():
        return