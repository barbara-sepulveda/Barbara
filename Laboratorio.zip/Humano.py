from Personaje import Personaje

class Humano(Personaje):
    def __init__(self, nombre,raza,arma,vida,dano,bonif,familia):
        super().__init__(nombre,raza,arma,vida,dano,bonif)
        self.__familia = familia

    def get_familia(self):
        return self.__familia   

    def set_familia(self, familia):
        self.__familia = familia

    def historia(self):
        print("Este humano desea pelear para descargar su ira.")

    def victoria(self):
        print("El humano ha vencido!")
    
    def derrota(self):
        print("Una lamentable baja humana.")

    def quita_vida():
        return