class Personaje():
    def __init__(self, nombre,raza,arma,vida,dano,bonif=0):
        self.__nombre = nombre
        self.__raza = raza
        self.__arma = arma
        self.__vida = vida
        self.__dano = dano
        self.__bonif = bonif

# Get y set
    def get_nombre(self):
        return self.__nombre

    def set_nombre(self, nombre):
        self.__nombre = nombre

    def get_raza(self):
        return self.__raza
        
    def set_raza(self, raza):
        self.__raza = raza
        
    def get_arma(self):
        return self.__arma
        
    def set_arma(self, arma):
        self.__arma = arma        

    def get_vida(self):
        return self.__vida        
    def set_vida(self, vida):
        self.__vida = vida

    def get_dano(self):
        return self.__dano
        
    def set_dano(self, dano):
        self.__dano = dano

    def get_bonif(self):
        return self.__bonif        
    def set_bonif(self, bonif):
        self.__bonif = bonif

# Métodos

    def combate():
        return
    
    def historia():
        return

    def victoria():
        return
    
    def derrota():
        return
    
    def mensaje_inicial(self):
        print("Mi nombre es " + self.get_nombre() + " y estoy listo para luchar")