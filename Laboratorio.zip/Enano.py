from Personaje import Personaje

class Enano(Personaje):
    def __init__(self, nombre,raza,arma,vida,dano,bonif,clan):
        super().__init__(nombre,raza,arma,vida,dano,bonif)
        self.__clan = clan

    def get_clan(self):
        return self.__clan
    
    def set_clan(self, clan):
        self.__clan = clan
    
    def historia(self):
        print("Un pequeño enano que solía trabajar en las minas de carbón.")

    def victoria(self):
        print("El enano se ha impuesto sobre su oponente!")
    
    def derrota(self):
        print("El enano debió permanecer como minero, las luchas no son lo suyo")

    def aumenta_vida(self):
        return