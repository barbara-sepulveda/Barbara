from Enano import Enano
from Elfo import Elfo
from Humano import Humano

def crear_pj():
    print("--- CREACIÓN ---")
    nombre = input("Nombre: ")
    raza = input("Raza (enano, elfo, humano): ").upper()
    arma = input("Arma (Espada, Maza, Arco): ").upper()
    if(arma=="ESPADA"):
        dano = 20
    elif(arma=="MAZA"):
        dano = 30
    elif(arma=="ARCO"):
        dano = 40

    # Se crea el personaje 
    if(raza=="ENANO"):
        vida = 130
        clan = input("Clan: ")
        return Enano(nombre,raza,arma,vida,dano,0,clan) # El 0 es la bonif que no se ha asignado
    elif(raza=="ELFO"):
        vida = 80
        reino = input("Reino: ")
        return Elfo(nombre,raza,arma,vida,dano,0,reino)
    elif(raza=="HUMANO"):
        vida = 100
        familia = input("Familia: ")
        return Humano(nombre,raza,arma,vida,dano,0,familia)

def mostrar_datos(p):
    print("Nombre: " + p.get_nombre())
    print("Raza: " + p.get_raza())
    if(p.get_raza()=="ENANO"):
        print("Clan: " + p.get_clan())
    elif(p.get_raza()=="ELFO"):
        print("Reino: " + p.get_reino())
    elif(p.get_raza()=="HUMANO"):
        print("Familia: " + p.get_familia())
    print("Arma: " + p.get_arma())
    print("Vida: " + p.get_vida())
    print("Dano: " + p.get_dano())
    print("Bonif: " + p.get_dano())

def hay_ganador(p1, p2):
    if(p1.get_vida() <= 0 or p2.get_vida() <= 0):
        return True
    

def ronda(p1, p2):
    print("Combate entre " + p1.get_nombre() + " vs " + p2.get_nombre())
    p2.set_vida(p2.get_vida()-p1.get_dano()) #P1 ataca a P2
    if(p2.get_vida() <= 0):
        print(p2.get_nombre() + " ha sido derrotado por " +p1.get_nombre())
        p2.derrota()
        p1.victoria()
    p1.set_vida(p1.get_vida() - p2.get_dano())
    if(p1.get_vida() <= 0):
        print(p1.get_nombre() + " ha sido derrotado por " +p2.get_nombre())
        p1.derrota()
        p2.victoria()

p1 = crear_pj()
p2 = crear_pj()    

p1.mensaje_inicial()
p2.mensaje_inicial()

numero_ronda = 10
while (numero_ronda <= 10):
    ronda(p1, p2)
    numero_ronda += 1
    if(numero_ronda>10 and hay_ganador(p1,p2)!=True):
        if(p1.get_vida()>p2.get_vida()):
            p1.victoria()
            p2.derrota()
        else:
            p2.victoria()
            p1.derrota()



    



